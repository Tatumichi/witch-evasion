# アーキテクチャ規約

> エージェントはコードを書く前にこのファイルを読む。
> `<>` の部分はプロジェクトごとに埋める。規約を変えたら `decisions.md` に理由を残す。

---

## 1. 環境

| 項目 | 値 |
|---|---|
| Godot | <4.7.x>(**このバージョンに固定**。途中で上げない) |
| 言語 | GDScript のみ |
| レンダラー | Compatibility(2D・幅広い環境向け)/ <変更する場合は理由を書く> |
| テスト | <GUT 9.x または gdUnit4 6.x。どちらか一方> |
| 対象プラットフォーム | <Windows / Web など> |

バージョン選びの原則:新規プロジェクトは **その時点の最新安定版(stable)** で始める。beta / dev 版は使わない。リリースまで同じマイナーバージョン(4.7.x の x だけ上げる)で通す。

---

## 2. フォルダ構成(機能単位)

シーン・スクリプト・素材は **機能ごとにまとめる**。種類別(scenes/ scripts/ に分ける)にはしない。関連ファイルが近くにある方が、人間もエージェントも探しやすい。

```
game/
├── project.godot
├── autoload/            # Autoload スクリプトのみ
├── core/                # 汎用部品(コンポーネント、基底クラス、ユーティリティ)
│   ├── components/      # health_component.gd, hitbox.gd, hurtbox.gd など
│   └── utils/
├── data/                # データ型の定義(class_name 付き Resource スクリプト)
│   ├── enemy_data.gd
│   └── item_data.gd
├── content/             # データの実体(.tres)。量産で増えるのはここ
│   ├── enemies/
│   └── items/
├── entities/            # プレイヤー・敵などのシーン
│   ├── player/          # player.tscn, player.gd, player.png
│   └── enemies/
│       ├── _base_enemy.tscn
│       └── slime/
├── levels/              # ステージ
├── ui/                  # 画面ごとにフォルダ
│   ├── hud/
│   ├── title/
│   └── pause_menu/
├── audio/               # bgm/, se/, default_bus_layout.tres
├── assets/              # 複数機能で共有する素材(フォント、共通テクスチャ)
└── tests/
    ├── unit/            # ロジックのテスト
    └── integration/     # シーンを使うテスト
```

- `_` で始まるファイルは基底(継承元)を表す
- 新しいトップレベルフォルダを作る場合は提案して人間の承認を得る

---

## 3. 命名規則(Godot 公式スタイルガイド準拠)

| 対象 | 規則 | 例 |
|---|---|---|
| ファイル・フォルダ | snake_case | `enemy_spawner.gd`, `pause_menu.tscn` |
| class_name | PascalCase | `class_name EnemyData` |
| ノード名 | PascalCase | `HealthComponent`, `AnimatedSprite2D` |
| 関数・変数 | snake_case | `func take_damage()`, `var max_hp` |
| プライベート | 先頭に `_` | `var _velocity`, `func _update_state()` |
| 定数 | UPPER_SNAKE_CASE | `const MAX_SPEED := 200.0` |
| enum | 型は PascalCase、値は UPPER_SNAKE_CASE | `enum State { IDLE, RUN }` |
| シグナル | 過去形 | `signal died`, `signal health_changed(new_hp: int)` |
| 入力アクション | snake_case | `move_left`, `attack`, `pause` |

ファイル名に大文字を使わない(Windows と他OSで大文字小文字の扱いが違い、エクスポート後に読み込めなくなる)。

---

## 4. スクリプトの書き方

### 4.1 型

- すべての変数・引数・戻り値に型を付ける
- 型が明らかなら `:=` で推論してよい(`var speed := 200.0`)
- 配列は型付き配列:`var enemies: Array[Enemy] = []`
- 辞書も可能なら型付き:`var counts: Dictionary[StringName, int] = {}`
- `get_node()` / `$` の結果は型付きで受ける:`@onready var _sprite: AnimatedSprite2D = $AnimatedSprite2D`

### 4.2 スクリプト内の並び順

```gdscript
class_name Enemy
extends CharacterBody2D
## このクラスの説明(1〜2行)

signal died

enum State { IDLE, CHASE, ATTACK }

const KNOCKBACK := 120.0

@export var data: EnemyData

var state: State = State.IDLE
var _target: Node2D

@onready var _health: HealthComponent = %HealthComponent


func _ready() -> void:
	pass


func _physics_process(delta: float) -> void:
	pass


func take_damage(amount: int) -> void:   # 公開関数
	pass


func _change_state(next: State) -> void:  # 非公開関数
	pass
```

### 4.3 その他

- マジックナンバー禁止。調整値は `@export` か定数か Resource に置く
- 1スクリプト1責務。**300行を超えたら分割を検討**(コンポーネントに切り出す)
- `print()` を残さない。デバッグ出力は `print_debug()` を使い、作業後に消す
- エラーは握りつぶさない。想定外は `push_error()` / `assert()`
- インデントはタブ(Godot エディタの既定)

---

## 5. シーン設計

### 5.1 通信のルール

- **上から下へは呼び出し、下から上へはシグナル**(親は子の関数を呼んでよい。子は親を知らない)
- 兄弟ノードを直接参照しない。親がつなぐか、EventBus を使う
- `get_parent()` と `../` を使った参照は禁止
- 子ノードの参照は `%UniqueName`(シーン内ユニーク名)か `@export` で渡す
- 長い `get_node("A/B/C/D")` は禁止

### 5.2 シーンは単体で動く

- 各 `.tscn` は単独で実行(F6)してもエラーにならないようにする
- 外部から必要なものは `@export` で受け取り、未設定なら `push_warning()` して安全に何もしない

### 5.3 コンポーネント

共通の機能はノード(コンポーネント)として切り出し、シーンに子として付ける。

| コンポーネント | 役割 |
|---|---|
| `HealthComponent` | HP の管理、`damaged` / `died` シグナル |
| `Hitbox`(Area2D) | 攻撃判定。ダメージ量を持つ |
| `Hurtbox`(Area2D) | 被弾判定。Hitbox と重なったら HealthComponent に伝える |
| <追加したら記入> | |

### 5.4 2D 固有

- マップは `TileMapLayer` を使う(`TileMap` は非推奨)
- 物理移動するキャラは `CharacterBody2D` + `move_and_slide()`
- 移動・物理は `_physics_process`、見た目の更新は `_process`
- UI は `CanvasLayer` の下に置き、カメラの影響を受けないようにする
- 描画順は `z_index` より **ノードの並び順と CanvasLayer** で管理する。`y_sort_enabled` を使う場合はここに記載

### 5.5 物理レイヤー(プロジェクト設定で名前を付ける)

| 番号 | 名前 | 用途 |
|---|---|---|
| 1 | world | 地形・壁 |
| 2 | player | プレイヤーの体 |
| 3 | enemy | 敵の体 |
| 4 | player_hitbox | プレイヤーの攻撃 |
| 5 | enemy_hitbox | 敵の攻撃 |
| 6 | pickup | 拾えるもの |
| <> | | |

コードでレイヤー番号を直接書かない。シーン上で設定する。

---

## 6. データ駆動

- 敵・アイテム・スキルなど **種類が増えるもの** は Resource で定義する
  - 型:`game/data/xxx_data.gd`(`class_name XxxData extends Resource`)
  - 実体:`game/content/<種類>/<名前>.tres`
- シーン側は `@export var data: XxxData` で受け取り、数値をハードコードしない
- 新しい種類を足すときは **.tres を増やすだけ** で済む形を目指す(コードを触らずに済むのが理想)
- 数百件規模になったら CSV / JSON から .tres を生成するツール化を検討(`decisions.md` に記録)

例:

```gdscript
class_name EnemyData
extends Resource

@export var id: StringName
@export var display_name: String
@export var max_hp: int = 10
@export var speed: float = 60.0
@export var damage: int = 1
@export var sprite_frames: SpriteFrames
@export var drop_table: Array[ItemData] = []
```

---

## 7. Autoload(シングルトン)

Autoload は「どこからでも触れる」ため、増えるほどバグの原因が追いにくくなる。**最小限** に保つ。

現在の Autoload 一覧(これ以外を追加する場合は提案して承認を得る):

| 名前 | ファイル | 役割 |
|---|---|---|
| `GameState` | `autoload/game_state.gd` | 現在の進行状況(セーブ対象のデータ) |
| `SaveManager` | `autoload/save_manager.gd` | セーブ/ロード、設定の保存 |
| `SceneRouter` | `autoload/scene_router.gd` | シーン遷移(フェード含む) |
| `AudioManager` | `autoload/audio_manager.gd` | BGM・SE の再生 |
| `EventBus` | `autoload/event_bus.gd` | 遠いノード同士のシグナル。**シグナル定義のみ、ロジックを書かない** |

- Autoload は他の Autoload 以外のノードを直接参照しない
- EventBus に定義するシグナルは、近くのノード同士なら通常のシグナルで済まないか先に検討する

---

## 8. セーブ/ロード

- 形式:**JSON**(`user://save_<スロット>.json`)。設定は `user://settings.cfg`(ConfigFile)
- **`user://` から .tres / .res を `load()` しない**。Godot の Resource ファイルは中に任意のコードを埋め込めるため、配布されたセーブデータ経由で悪意あるコードが実行される危険がある
- セーブデータには必ず `"version": <整数>` を入れる。形式を変えたら version を上げ、古い形式を読み込むための変換関数を `SaveManager` に足す
- 書き込みは「一時ファイルに書く → 成功したら本ファイルに置き換える」の順にする(書き込み中のクラッシュでセーブが壊れないように)
- 読み込みで失敗したら、セーブを消さずにエラーを出してタイトルに戻す
- 各ノードの状態は `to_dict() -> Dictionary` / `from_dict(d: Dictionary) -> void` で出し入れする
- Vector2 などは JSON にそのまま入らないので `{"x":..,"y":..}` に変換する

---

## 9. シーン遷移

- 遷移は必ず `SceneRouter` を通す(各シーンが `get_tree().change_scene_to_file()` を直接呼ばない)
- シーンのパスは `SceneRouter` の定数にまとめる

---

## 10. 入力

- 入力はすべて InputMap のアクション名で扱う(キーコードを直接書かない)
- 定義済みアクション:<move_left, move_right, move_up, move_down, attack, interact, pause, ...>
- キーボードとゲームパッドの両方を割り当てる
- アクションを追加したらこの一覧を更新する

---

## 11. プロジェクト設定(Phase 2 で行う)

| 設定 | 値 | 理由 |
|---|---|---|
| Display > Window > Viewport Width/Height | <例:640×360> | 基準解像度 |
| Display > Window > Stretch > Mode | <viewport(ピクセルアート) / canvas_items(高解像度)> | |
| Display > Window > Stretch > Scale Mode | <integer(ピクセルアート) / fractional> | にじみ防止 |
| Rendering > Textures > Canvas Textures > Default Texture Filter | <Nearest(ピクセルアート)/ Linear> | |
| Debug > GDScript > Warnings > Untyped Declaration | **Error** | 型の付け忘れ防止 |
| Debug > GDScript > Warnings > Unsafe Property/Method Access | Warn 以上 | 型の抜け道を検出 |

(Advanced Settings を有効にすると Debug > GDScript が表示される)

---

## 12. テスト

- フレームワーク:<GUT / gdUnit4>
- 置き場所:`game/tests/unit/`(ロジック)、`game/tests/integration/`(シーン)
- ファイル名:`test_<対象>.gd`
- テストを書く対象(優先順):
  1. ダメージ計算、インベントリ、ドロップ抽選などの **ロジック**
  2. セーブデータの `to_dict` / `from_dict` の往復
  3. セーブデータのバージョン変換
  4. データ(.tres)の整合性(必須項目が空でないか、ID の重複がないか)
- 乱数を使う処理は、シード(または RandomNumberGenerator)を外から渡せるようにする
- 実行方法は `docs/commands.md`

---

## 13. 禁止事項まとめ

- Godot 3 の API・構文(`docs/gdscript_pitfalls.md`)
- 型のない宣言
- `get_parent()` / `../` による参照
- `user://` からの Resource 読み込み
- 承認なしの Autoload 追加、トップレベルフォルダ追加
- テストの削除・無効化
- 依頼範囲外のファイル変更
