# Godot 4 / GDScript の落とし穴

> AI は学習データに Godot 3 の情報を多く含むため、古い書き方を混ぜやすい。
> コードを書く前と、レビュー時に確認する。**新しい間違いを見つけたら下に追記する。**

---

## 1. Godot 3 → 4 の置き換え表

### 構文・アノテーション

| ✗ Godot 3 | ✓ Godot 4 |
|---|---|
| `export var hp = 10` | `@export var hp: int = 10` |
| `onready var x = $X` | `@onready var x: Node2D = $X` |
| `tool` | `@tool` |
| `yield(obj, "done")` | `await obj.done` |
| `var x setget set_x` | `var x: int:` + `set(v):` / `get:` ブロック |
| `extends Reference` | `extends RefCounted` |
| `funcref(obj, "f")` | `obj.f`(Callable) |

### シグナル

| ✗ Godot 3 | ✓ Godot 4 |
|---|---|
| `connect("pressed", self, "_on_pressed")` | `pressed.connect(_on_pressed)` |
| `emit_signal("died")` | `died.emit()` |
| `disconnect("pressed", self, "_on_pressed")` | `pressed.disconnect(_on_pressed)` |
| 引数のバインド `[arg]` | `_on_x.bind(arg)` |

### ノード・クラス名

| ✗ Godot 3 | ✓ Godot 4 |
|---|---|
| `KinematicBody2D` | `CharacterBody2D` |
| `move_and_slide(velocity, Vector2.UP)` | `velocity = ...` を設定してから `move_and_slide()`(引数なし) |
| `Sprite` | `Sprite2D` |
| `AnimatedSprite` | `AnimatedSprite2D` |
| `Position2D` | `Marker2D` |
| `YSort` | `Node2D` の `y_sort_enabled = true` |
| `TileMap`(Godot 4 初期も含む) | `TileMapLayer`(TileMap は非推奨) |
| `Tween` ノードを置く | `var t := create_tween()` |
| `RigidBody2D.mode` | `freeze` / `freeze_mode` |
| `VisibilityNotifier2D` | `VisibleOnScreenNotifier2D` |

### 関数・ユーティリティ

| ✗ Godot 3 | ✓ Godot 4 |
|---|---|
| `scene.instance()` | `scene.instantiate()` |
| `get_tree().change_scene("res://...")` | `get_tree().change_scene_to_file("res://...")`(本プロジェクトでは SceneRouter 経由) |
| `update()`(再描画) | `queue_redraw()` |
| `File.new()` / `file.open()` | `FileAccess.open(path, FileAccess.READ)` |
| `Directory.new()` | `DirAccess.open(path)` |
| `to_json(d)` / `parse_json(s)` | `JSON.stringify(d)` / `JSON.parse_string(s)` |
| `str2var` / `var2str` | `str_to_var` / `var_to_str` |
| `deg2rad` / `rad2deg` | `deg_to_rad` / `rad_to_deg` |
| `rand_range(a, b)` | `randf_range(a, b)` / `randi_range(a, b)` |
| `stepify(x, s)` | `snapped(x, s)` |
| `OS.get_ticks_msec()` | `Time.get_ticks_msec()` |
| `PoolStringArray` など | `PackedStringArray` など |
| `linear_interpolate` | `lerp` |

---

## 2. AI がよく犯す間違い

- **存在しないメソッドやプロパティを作り出す。** 自信がないAPIは Godot 内蔵のドキュメント(エディタの F1 検索)で確認する。確認できなければ「未確認」と報告する
- **`super()` の呼び忘れ。** 親クラスの `_ready()` などを上書きするときは、必要なら `super()` を呼ぶ
- **`$` のパス直書き。** ノード名を変えると壊れる。`%UniqueName` を使う
- **`:=` に null を代入。** `var target := null` は型が決まらない。`var target: Node2D = null` と書く
- **型付き配列への代入ミス。** `Array[Enemy]` に型なし配列を代入するとエラーになる
- **`_process` で物理移動。** 移動・衝突は `_physics_process`
- **`queue_free()` 後のアクセス。** 解放予定のノードを触る前に `is_instance_valid()` で確認する
- **シグナルの二重接続。** `_ready` が複数回呼ばれる構成では `is_connected()` を確認するか、エディタ上で接続する
- **`await` の後でノードが消えている。** await の後は `is_inside_tree()` を確認する
- **`@onready` 変数を `_init()` で使う。** `_ready()` より前は null
- **整数の割り算。** `5 / 2` は `2`。小数が必要なら `5 / 2.0`
- **Resource の共有。** `@export` した Resource をインスタンスごとに変更すると全員に反映される。個別に変えるなら `duplicate()` するか、`resource_local_to_scene` を使う
- **UI の入力が奥のゲームに抜ける。** UI 側で `accept_event()` するか、`mouse_filter` を確認する
- **ポーズ中に動かない。** ポーズメニューなどは `process_mode = PROCESS_MODE_ALWAYS`

---

## 3. このプロジェクトで実際に起きた間違い

<!-- 見つけたら追記。形式:- YYYY-MM-DD:<間違い> → <正しいやり方> -->

-
