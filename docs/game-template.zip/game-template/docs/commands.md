# コマンド集

> エージェントはテスト・実行にここのコマンドを使う。Phase 2 で **自分の環境で全部動くことを確認** してから埋める。
> `godot` の部分は実際の実行ファイル名・パスに置き換える(例:`Godot_v4.7.2-stable_win64_console.exe`)。
> Windows では **`_console.exe` 版** を使うと出力がターミナルに表示される。

## 環境
- Godot 実行ファイル:<フルパスを記入>
- OS:<Windows / macOS / Linux>
- シェル:<PowerShell / bash>

---

## 起動・確認

```bash
# エディタを開く
godot --path game --editor

# ゲームを実行する
godot --path game

# 特定のシーンだけ実行する
godot --path game res://levels/test_level.tscn

# 素材のインポートだけ行って終了(初回・CI・素材追加後)
godot --headless --path game --import

# スクリプトの構文チェック(実行はしない)
godot --headless --path game --check-only --script res://entities/player/player.gd
```

## テスト

### GUT を使う場合
```bash
# すべてのテスト
godot --headless --path game -s addons/gut/gut_cmdln.gd -gdir=res://tests -ginclude_subdirs -gexit

# 1ファイルだけ
godot --headless --path game -s addons/gut/gut_cmdln.gd -gtest=res://tests/unit/test_health_component.gd -gexit
```

### gdUnit4 を使う場合
gdUnit4 に同梱の実行スクリプト(`addons/gdUnit4/runtest.sh` / `runtest.cmd`)を使う。引数は導入したバージョンのドキュメントで確認して、ここに記入する。
```bash
<記入>
```

**判定方法**:終了コードが 0 なら成功。エージェントは出力の最後(失敗数・エラー)を報告に含める。

## エクスポート

エクスポート前に、エディタで Project > Export からプリセットを作り、エクスポートテンプレートをインストールしておく。プリセット名はコマンドと **完全一致** させる。

```bash
# リリースビルド
godot --headless --path game --export-release "Windows Desktop" ../build/windows/<game>.exe
godot --headless --path game --export-release "Web" ../build/web/index.html

# デバッグビルド
godot --headless --path game --export-debug "Windows Desktop" ../build/windows_debug/<game>.exe
```

`build/` は `.gitignore` 済み。

## Git(よく使うもの)

```bash
git switch -c task/<名前>     # タスク開始
git diff                      # 変更確認
git add -A && git commit -m "<種類>: <内容>"
git switch main && git merge task/<名前>
git branch -D task/<名前>      # 失敗したタスクを捨てる(main に戻ってから)
git tag v0.1.0                # マイルストーン
```

コミットメッセージの種類:`feat`(機能)/ `fix`(バグ修正)/ `content`(データ追加)/ `refactor` / `test` / `docs` / `chore`
