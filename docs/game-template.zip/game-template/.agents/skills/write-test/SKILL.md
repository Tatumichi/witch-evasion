---
name: write-test
description: ロジックやデータにテストを追加するとき。新機能の実装時、バグ修正時(再発防止)、データ追加時に使う。
---

# スキル:テストを書く

## 前提
- 読むファイル:`docs/architecture.md` の「12. テスト」、`docs/commands.md`
- フレームワーク:architecture.md に書かれている方(GUT か gdUnit4)。**混ぜない**
- 置き場所:`game/tests/unit/`(ロジック)、`game/tests/integration/`(シーンを使う)
- ファイル名:`test_<対象>.gd`

## 何をテストするか(優先順)
1. 計算・判定ロジック(ダメージ、ドロップ抽選、インベントリの増減、状態遷移)
2. セーブデータの往復(`to_dict()` → `from_dict()` で同じ状態に戻る)
3. セーブデータの旧バージョンからの変換
4. データの整合性(全 .tres の必須項目が埋まっている、ID が重複していない)
5. バグ修正時:そのバグを再現するテスト(修正前に失敗し、修正後に通る)

テストしにくいもの(見た目、手触り)は無理にテストしない。人間のプレイ確認に回す。

## 手順
1. テスト対象の公開関数と、期待する結果を箇条書きにする(正常系・境界値・異常系)
2. テストファイルを作る / 既存ファイルに追記する
3. 1テスト1確認。テスト名で何を確かめるか分かるようにする
   - 例:`test_take_damage_reduces_hp`、`test_hp_does_not_go_below_zero`
4. 乱数を使う処理は、シードを固定した RandomNumberGenerator を渡す
5. ノードを生成した場合は、テスト後に解放する(フレームワークの自動解放機能を使う)
6. テストを実行し、**通ることと、わざと壊したら失敗すること** を確認する

## GUT の書き方の例

```gdscript
extends GutTest

var _health: HealthComponent


func before_each() -> void:
	_health = HealthComponent.new()
	_health.max_hp = 10
	add_child_autofree(_health)


func test_take_damage_reduces_hp() -> void:
	_health.take_damage(3)
	assert_eq(_health.hp, 7)


func test_hp_does_not_go_below_zero() -> void:
	_health.take_damage(99)
	assert_eq(_health.hp, 0)


func test_died_emitted_when_hp_reaches_zero() -> void:
	watch_signals(_health)
	_health.take_damage(10)
	assert_signal_emitted(_health, "died")
```

(gdUnit4 を使う場合は、このプロジェクトで最初に書いたテストを例としてここに差し替える)

## やってはいけないこと
- 既存テストの削除・無効化・期待値を実装に合わせて書き換えること(仕様変更の場合は人間に確認)
- 実装の内部(private 変数)を直接確認するテスト
- 常に通るテスト(assert がない、条件が常に真)

## よくある失敗
- `_ready()` が呼ばれる前提のノードを `new()` しただけで使う → ツリーに追加する
