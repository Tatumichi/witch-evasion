# prototype/

Phase 1 の使い捨てプロトタイプ用。`game/` とは **別の Godot プロジェクト** としてここに作る。

- 目的は `docs/design.md` の「プロトタイプで確かめる問い」に答えることだけ
- 規約・見た目・コード品質は気にしない
- ここのコードは `game/` にコピーしない(作り直す)
- 結果は `docs/playtest.md` と `docs/decisions.md` に記録する
- 複数の案を試すときは `prototype/a_<名前>/`、`prototype/b_<名前>/` のように分ける
